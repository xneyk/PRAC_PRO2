var searchData=
[
  ['existscitywithid_0',['existsCityWithId',['../classRiver.html#aa275ac48e7c0651c701a3cf6e59a4cc2',1,'River']]],
  ['existsproductwithid_1',['existsProductWithId',['../classProductSet.html#a9e72f64b01517b702b7aadd0e2f9ee1f',1,'ProductSet']]]
];
