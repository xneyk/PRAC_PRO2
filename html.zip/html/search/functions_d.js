var searchData=
[
  ['updatestatus_0',['updateStatus',['../classTravel.html#acc1c1c7942c1a3a3a1df518782043f60',1,'Travel']]]
];
