var searchData=
[
  ['read_0',['read',['../classCity.html#a60bb537d78e8e014b70553d85574a29d',1,'City::read()'],['../classRiver.html#aa63888336261fd57b19b7682b7d0a85f',1,'River::read()']]],
  ['readcitywithid_1',['readCityWithId',['../classRiver.html#a00be16307fc6918296f725a48dccb471',1,'River']]],
  ['redistribute_2',['redistribute',['../classRiver.html#a150c8d38fa0312d86b86c807483e85c4',1,'River']]],
  ['removeproduct_3',['removeProduct',['../classCity.html#a1d6f9c33535552b31dafbf9d3d0e32e4',1,'City::removeProduct()'],['../classRiver.html#a9456f318afee5ba8f9bd0411e5fa53f8',1,'River::removeProduct(string city_name, int id, const ProductSet &amp;product_set)']]],
  ['river_4',['River',['../classRiver.html#a305d3ec8496a5373328045da3b8d8362',1,'River']]]
];
